package model;

import model.Card.Rank;

public class TableauPile extends CardPile {
	
	Integer initialSize;
	//n = how many cards
	public TableauPile(Integer n) {
		super();
		initialSize = n;
	}
	
	@Override
	public boolean isValid(Card card) {
		if(isEmpty() ) {
			return card.getRank() == Rank.KING;
		}
		Card topCard = getTop();
		return (!topCard.isSameColor(card) && topCard.isHigherRank(card));
	}
	
}
