package model;

import java.util.Collections;
import model.Card.Suit;
import model.Card.Rank;

public class DeckPile extends CardPile{
	
	public DeckPile() {
		super();
		setCards();
		shuffle();
	}
	
	//creates the cards and stores it in a stack
	private void setCards() {
		for(Suit suit : Suit.values()) {
			for(Rank rank: Rank.values()) {
				push(new Card(suit, rank));
			}
		}
	}
	
	public void shuffle() {
		Collections.shuffle(this.pile);
	}
	
	public int getSize() {
		return this.pile.size();
	}
	
	@Override
	public void push(Card card) {
		if(card.getFace() ) {
			card.flipCard();
		}
		super.push(card);
	}

}