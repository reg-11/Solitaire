package model;

import java.util.EmptyStackException;
import java.util.Stack;

public class CardPile {
	public Stack<Card> pile;
	
	public CardPile() {
		this.pile = new Stack<Card>();
	}
	
	public final boolean isEmpty() {
		return pile.isEmpty();
	}
	
	public final Card getTop() {
		return pile.peek();
	}
	
	public final Card pop() {
		try {
			return pile.pop();
		} catch (EmptyStackException e) {
			return null;
		}
	}
	
	public void copy(CardPile stackToCopy) {
		Stack<Card> temp = new Stack<Card>();
		for(Card card : stackToCopy.pile) {
			temp.push(card);
		}
		for(Card card : temp) {
			push(card);
		}
	}
	
	public void push(Card card) {
		pile.push(card);
		
	}
	
	public boolean isValid(Card card) {
		return false;
	}
	
}

