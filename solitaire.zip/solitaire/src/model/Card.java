package model;

public class Card {

    public enum Suit {
        CLUBS, DIAMONDS, HEARTS, SPADES
    }
    
    public enum Rank  {
        ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING
    }
    
    private final Suit cardSuit;
    private final Rank cardRank;
    
    //initial face down
    private boolean faceUp;
    
    public Card(Suit cardSuit, Rank cardRank) {
        this.cardSuit = cardSuit;
        this.cardRank = cardRank;
    }
    
    public Suit getSuit() {
        return cardSuit;
    }  
    
    public Rank getRank() {
        return cardRank;
    }
    
    public boolean getFace() {
        return faceUp;
    }
    
    public boolean flipCard() {
        faceUp = !faceUp;
        return faceUp;
    }
    
    public boolean isSameColor(Card otherCard) {
        if(otherCard == null) {
            return false;
        }
        else {
            Suit currSuit = getSuit();
            Suit otherSuit = otherCard.getSuit();
            if(currSuit == Suit.DIAMONDS || currSuit == Suit.HEARTS) {
                if(otherSuit == Suit.DIAMONDS || otherSuit == Suit.HEARTS) {
                    return true;
                }
                return false;
            }
            else {
                if(otherSuit == Suit.CLUBS || otherSuit == Suit.SPADES) {
                    return true;
                }
                return false;
            }
        }
    }
    
    public boolean isLowerRank(Card otherCard) {
        Integer currRank = getRank().ordinal();
        Integer otherRank = otherCard.getRank().ordinal();
        
        if(currRank.equals(otherRank - 1)) {
            return true;
        }
        return false;
    }
    
    public boolean isHigherRank(Card otherCard) {
        Integer currRank = getRank().ordinal();
        Integer otherRank = otherCard.getRank().ordinal();
        
        if(currRank.equals(otherRank + 1)) {
            return true;
        }
        return false;
    }
    
    public boolean isSameSuit(Card otherCard) {
    	if(otherCard == null) {
            return false;
        }
        else {
            Suit currSuit = getSuit();
            Suit otherSuit = otherCard.getSuit();
            if(currSuit == otherSuit) {
            	return true;
            }
            else {
            	return false;
            }
        }
    }
    
    public boolean equals(Card otherCard) {
    	return(getRank().equals(otherCard.getRank()) && getSuit().equals(otherCard.getSuit()));
    }
    
    public String toString() {
    	return getRank() + " of " + getSuit();
    }
}
