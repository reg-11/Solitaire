
package model;
import java.util.Stack;
import model.Card.Rank;

public class Solitaire {
	public TableauPile[] tableau = new TableauPile[7];
	public DeckPile deck = new DeckPile();
	public DiscardPile discard = new DiscardPile();
	public FoundationPile[] foundation = new FoundationPile[4];
	private Integer draw;
	public Integer score = 0;

	public Solitaire(Integer draw) {
		
		for(int i = 0; i < 7; i++) {
			tableau[i] = new TableauPile(i+1);
		}
		
		for(int i = 0; i < 4; i++) {
			foundation[i] = new FoundationPile();
		}
		
		for(int i = 0; i < 7; i++) {
			if(i == 0) {
				tableau[0].push(deck.pop());
			}
			if(i <= 1) {
				tableau[1].push(deck.pop());
			}
			if(i <= 2) {
				tableau[2].push(deck.pop());
			}
			if(i <= 3) {
				tableau[3].push(deck.pop());
			}
			if(i <= 4) {
				tableau[4].push(deck.pop());
			}
			if(i <= 5) {
				tableau[5].push(deck.pop());
			}
			if(i <= 6) {
				tableau[6].push(deck.pop());
			}
		}	
		
		for(int i = 0; i < 7; i++) {
			tableau[i].getTop().flipCard();
		}
		this.draw = draw;
	}
	
	public boolean move(CardPile source, CardPile target) {
		if(target instanceof FoundationPile) {
			return moveToFoundation(source, (FoundationPile) target);
		}
		else if(target instanceof TableauPile) {
			return moveToTableau(source, (TableauPile) target);
		}
		else if ((source instanceof DeckPile && target instanceof DiscardPile && !deck.isEmpty()) ||
				 (source instanceof DiscardPile && target instanceof DeckPile && deck.isEmpty())){
			moveToDiscard();
			return true;
		}
		else {
			return false;
		}
	}
	
	private void moveToDiscard() {
		if(!deck.isEmpty()) {
			for(int i = 0; i < draw; i++) {
				discard.push(deck.pop());
			}	
		}
		else {
			while(!discard.isEmpty()) {
				deck.push(discard.pop());
			}
		}
	}
	
	private boolean moveToFoundation(CardPile cPile, FoundationPile fPile) {
		if(fPile.isValid(cPile.getTop())) {
			fPile.push(cPile.pop());
			return true;
		}
		return false;
	}
	
	private boolean moveToTableau(CardPile cPile, TableauPile tPile) {
		if(cPile instanceof DiscardPile || cPile instanceof FoundationPile) {
			if(tPile.isValid(cPile.getTop())) {
				tPile.push(cPile.pop());
				return true;
			}
		}
		else if(cPile instanceof TableauPile) {
			//Case na 1 card valid na
			if(tPile.isValid(cPile.getTop())) {
				tPile.push(cPile.pop());
			}
			//if king stack moved to empty
			else if(tPile.isEmpty()) {
				CardPile temp = new CardPile();
				temp.copy(cPile);
				System.out.println("IN");
				while(!temp.getTop().getRank().equals(Rank.KING)) {
					temp.pop();
				}
				System.out.println(temp.getTop());
				if(tPile.isValid(temp.getTop())) {
					System.out.println("INNNN");
					Stack<Card> s1 = new Stack<Card>();
					while(!cPile.getTop().equals(temp.getTop())) {
						s1.push(cPile.pop());
					}
					s1.push(cPile.pop());
					while(!s1.isEmpty()) {
						tPile.push(s1.pop());
					}
					return true;
				}
			}
			// Case na stack of cards yung minove
			else { 
				CardPile temp = new CardPile();
				temp.copy(cPile);
				while(tPile.getTop().getRank().ordinal() - temp.getTop().getRank().ordinal() > 1) {
					if(temp.getTop().getFace()) {
						temp.pop();
					}
				}
				if(tPile.isValid(temp.getTop())) {
					Stack<Card> s1 = new Stack<Card>();
					while(!cPile.getTop().equals(temp.getTop())) {
						s1.push(cPile.pop());
					}
					s1.push(cPile.pop());
					while(!s1.isEmpty()) {
						tPile.push(s1.pop());
					}
					return true;
				}
			}
			
		}
		return false;
		
	
	}
	
	public Integer getScore() {
		return score;
	}
	
	public void setScore(CardPile source, CardPile target) {
		if(source instanceof DiscardPile && target instanceof TableauPile) {
			score += 5;
		}
		else if((source instanceof DiscardPile && target instanceof FoundationPile) ||
				(source instanceof TableauPile && target instanceof FoundationPile)) {
			score += 10;
		}
		else if(source instanceof TableauPile) {
			CardPile temp = new CardPile();
			temp.copy(source);
			temp.pop();
			if(!temp.getTop().getFace()) {
				score += 5;
			}
		}
		else if(source instanceof FoundationPile && target instanceof TableauPile) {
			score -= 15;
		}
		else if(draw.equals(1) && discard.isEmpty()) {
			score -= 100;
		}
		
		if(score < 0) {
			score = 0;
		}
	}
	
	public void updateTableau() {
		for(TableauPile tp : tableau) {
			if(!tp.isEmpty() && !tp.getTop().getFace()) {
				tp.getTop().flipCard();
			}
		}
	}
	
	public boolean gameWon() {
		for(FoundationPile fp : foundation) {
			if(fp.pile.size() != 13) {
				return false;
			}
		}
		return true;
	}
}
