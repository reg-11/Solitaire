package model;

public class DiscardPile extends CardPile {

	public DiscardPile() {
		super();
	}
	
	@Override
	public void push(Card card) {
		if(!card.getFace()) {
			card.flipCard();
		}
		super.push(card);
	}
	
}
