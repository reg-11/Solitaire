
package model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Player {

	private SimpleStringProperty name;
	private SimpleIntegerProperty score;
	
	public Player(String name, Integer score) {
		this.name = new SimpleStringProperty(name);
		this.score = new SimpleIntegerProperty(score);
	}
	
	@Override
	public boolean equals(Object o) {
		if(!(o instanceof Player)) {
			return false;
		}
		Player other = (Player) o;
		return this.name.get().contentEquals(other.getName());
	}
	
	public String getName() {
		return name.get();
	}
	
	public Integer getScore() {
		return score.get();
	}
	
	public void setName(String name) {
		this.name.set(name);
	}
	
	public void setScore(Integer score) {
		this.score.set(score);
	}
}

