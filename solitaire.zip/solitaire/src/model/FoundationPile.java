package model;

import model.Card.Rank;

public class FoundationPile extends CardPile{
	
	public FoundationPile() {
		super();
	}
	
	@Override
	public boolean isValid(Card card) {
		if(isEmpty()) {
			return card.getRank() == Rank.ACE;
		}
		Card topCard = getTop();
		return(topCard.isSameSuit(card) && topCard.isLowerRank(card));
	}
	
}

