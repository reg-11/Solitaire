package controller;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class NamePromptController {
	
	//pop up window to get the name of player if player wins
	@FXML
	private Button done;
		
	@FXML
	private TextField name;
	
	private Integer score;
		
	@FXML
	private void closeWindow(ActionEvent event) {
		try {
			List<String> line = Files.readAllLines(Paths.get(this.getClass().getResource("LeaderboardRecord.txt").toURI()));
			Iterator<String> iter = line.iterator();
			
			if (line.isEmpty()) {
				line.add(getName() + " " + score);
			}
			else {
				int i = 0;
				while(iter.hasNext()) {
					String s = iter.next();
					Integer lineScore = Integer.valueOf(s.split(" ")[1]);
					if(lineScore <= score) {
						break;
					}
					i++;
					
				}
				line.add(i, getName() + " " + score );
				if(line.size() > 10) {
					line.remove(10);
				}
			}
	
			FileWriter writer = new FileWriter("C:\\Users\\Jenalyn\\Documents\\2nd Year - 1st Sem\\CMSC23\\Lab Exercises\\cmsc23-workspace\\solitaire\\src\\controller\\LeaderboardRecord.txt");
			//writer.write("");
			for (String s : line) {
				writer.write(s + "\n");
			}
			writer.close();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		
		Stage stage = (Stage) done.getScene().getWindow();
		stage.close();
	}
	
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getName() {
		return name.getText();
	}

}
