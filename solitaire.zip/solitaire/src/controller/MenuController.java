package controller;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MenuController {
	private Main main;

    @FXML
    private Pane pane;
	
    @FXML
    private Button newGameButton;

    @FXML
    private Button leaderboardButton;

    @FXML
    private Button exitButton;
    
    public void setMain(Main main) {
    	this.main = main;
	}

    @FXML
    private void exitGame(ActionEvent event) {
    	Stage stage = (Stage) exitButton.getScene().getWindow();
		stage.close();
    }
    
    @FXML
    private void openLeaderboard(ActionEvent event) {
    	main.openLeaderboardView();
    }

    @FXML
    private void openNewGame(ActionEvent event) {
    	main.openNewGameView();
    }
}
