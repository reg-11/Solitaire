package controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import model.Player;

public class LeaderboardController {
	private Main main;
	
	@FXML
    private Pane pane;

    @FXML
    private TableView<Player> playerRosterView;
	
	@FXML
    private TableColumn<Player, String> nameColumn;

    @FXML
    private TableColumn<Player, Double> scoreColumn;

    @FXML
    private Button backButton;
    
    private ObservableList<Player> playerRoster;
    
    public void setMain(Main main) {
		this.main = main;
	}
    
	@FXML
	private void initialize() {
		playerRoster = FXCollections.observableArrayList();
		playerRosterView.setItems(playerRoster);
		nameColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("name"));
		scoreColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("score"));
		setContents();
	}

    @FXML
    private void openMainMenu(ActionEvent event) {
    	main.openMenuView();
    }
    
    public void setContents() {
    	//reads from file to get high score record
    	BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader("src/controller/LeaderboardRecord.txt"));
			String line = reader.readLine();
			String[] playerRecord;
			
			while(line != null) {
				playerRecord = line.split(" ");
				Player player = new Player(playerRecord[0], Integer.valueOf(playerRecord[1]));
				playerRoster.add(player);
				line = reader.readLine();
			}

		} 
		catch(IOException e) {
			System.err.println("Cannot open file! Please try again.");
			//e.printStackTrace();
		}
		finally {
			try {
				if(reader != null) {
					reader.close();
				}
			}
			catch(Exception e) {
				System.err.println("An error occurred, please try again.");
				//e.printStackTrace();
			}
		}
    }
    
    
}
