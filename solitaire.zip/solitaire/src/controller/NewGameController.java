package controller;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class NewGameController {
	
	private Main main;
	
	@FXML
    private Pane pane;

    @FXML
    private Button drawOneButton;

    @FXML
    private Button drawThreeButton;
    
    @FXML
    private Button backButton;
    
    public void setMain(Main main) {
		this.main = main;
	}

    @FXML
    private void openDrawOneGame(ActionEvent event) {
    	main.openDrawOneGame();
    }

    @FXML
    private void openDrawThreeGame(ActionEvent event) {
    	main.openDrawThreeGame();
    }

    @FXML
    private void openMainMenu(ActionEvent event) {
    	main.openMenuView();
    }
	
}
