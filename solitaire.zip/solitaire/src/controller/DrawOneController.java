package controller;

import java.io.File;
import java.util.HashMap;
import java.util.LinkedList;

import application.Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import model.Card;
import model.DeckPile;
import model.DiscardPile;
import model.Card.Rank;
import model.Card.Suit;
import model.CardPile;
import model.FoundationPile;
import model.Solitaire;
import model.TableauPile;

public class DrawOneController {

	//constructor argument draw 1
	Solitaire game = new Solitaire(1);
	
	private Main main;
	
    @FXML
    private VBox TP1 = new VBox();

    @FXML
    private VBox TP2 = new VBox();
    
    @FXML
    private VBox TP3 = new VBox();

    @FXML
    private VBox TP4 = new VBox();

    @FXML
    private VBox TP5 = new VBox();

    @FXML
    private VBox TP6 = new VBox();

    @FXML
    private VBox TP7 = new VBox();
    
    @FXML
    private StackPane FP4 = new StackPane();

    @FXML
    private StackPane FP3 = new StackPane();

    @FXML
    private StackPane FP2 = new StackPane();

    @FXML
    private StackPane FP1 = new StackPane();

    @FXML
    private StackPane DcP = new StackPane();

    @FXML
    private StackPane DP = new StackPane();
    
    @FXML
    private Text scoreText;

    @FXML
    private Button quitButton;

    @FXML
    private Button newGameButton;
	
    //temp stores pile be moved
	private CardPile move;
	//inaassign yung mga fxml box to solitaire
	private HashMap<TableauPile, VBox> tMap = new HashMap<TableauPile, VBox>();
	private HashMap<FoundationPile, StackPane> fMap = new HashMap<FoundationPile, StackPane>();
	//stores score for label
	private Integer score;

	
	public void setMain(Main main) {
		this.main = main;
	}
	
	public void initialize() {
		//assigns to hashmap
		tMap.put(game.tableau[0], TP1);
		tMap.put(game.tableau[1], TP2);
		tMap.put(game.tableau[2], TP3);
		tMap.put(game.tableau[3], TP4);
		tMap.put(game.tableau[4], TP5);
		tMap.put(game.tableau[5], TP6);
		tMap.put(game.tableau[6], TP7);
		
		fMap.put(game.foundation[0], FP1);
		fMap.put(game.foundation[1], FP2);
		fMap.put(game.foundation[2], FP3);
		fMap.put(game.foundation[3], FP4);
		
		resetView();
	}
	
	private void resetView() {
		//remove old view then replace accdg to move by user
		for(TableauPile tp : game.tableau) {
			tMap.get(tp).getChildren().clear();
			setTableauView(tMap.get(tp), tp);
		}
		for(FoundationPile fp : game.foundation) {
			fMap.get(fp).getChildren().clear();
			setFoundationsView(fMap.get(fp), fp);
		}
		DcP.getChildren().clear();
		setDeckView(DcP, game.deck);
		DP.getChildren().clear();
		setDiscardView(DP, game.discard);
		score = game.getScore();
		setScoreCounter(score.toString());
	}
	
	private Image getImage(Card currCard) {
		String fileName;
		if(currCard.getFace()) {
			Rank currRank = currCard.getRank();
    		Suit currSuit = currCard.getSuit();
    		
    		fileName = "C:\\Users\\Jenalyn\\Documents\\2nd Year - 1st Sem\\CMSC23\\Lab Exercises\\cmsc23-workspace\\solitaire\\src\\image\\" + currSuit.toString() + currRank.toString() + ".gif";
		}
		else {
			fileName = "C:\\Users\\Jenalyn\\Documents\\2nd Year - 1st Sem\\CMSC23\\Lab Exercises\\cmsc23-workspace\\solitaire\\src\\image\\bg.gif";
		}
		
		File image = new File(fileName);
		return new Image(image.toURI().toString());
	}
	
	private LinkedList<Image> getImageList(CardPile pile) {
		CardPile temp = pile;
		LinkedList<Image> images = new LinkedList<Image>();
		while(!temp.isEmpty()) {
			Card currCard = temp.getTop();
			images.push(getImage(currCard));
			temp.pop();
		}
		return images;
	}
	
	private void setTableauView(VBox tView, TableauPile pile) {
		CardPile temp = new CardPile();
        temp.copy(pile);
        
		//padding - for element to border
        //margin - element to element
		tView.setPadding(new Insets(80, 0, 0, 0));
		for(Image img : getImageList(temp)) {
			ImageView cardView = new ImageView(img);
			VBox.setMargin(cardView, new Insets(-80, 0, 0, 0));
			
			tView.getChildren().add(cardView);
		}
		
		tView.setOnDragDetected(new EventHandler<MouseEvent>() {
    		@Override
    		public void handle(MouseEvent event) {
    			Dragboard db = tView.startDragAndDrop(TransferMode.ANY);
    			ClipboardContent cb = new ClipboardContent();
    	        move = pile;
    			cb.putString("move");
    			db.setContent(cb);
    	        event.consume();
    	        System.out.println("source detect");
    	    }
    	});
		tView.setOnDragOver(createDragOverHandler(pile));
		tView.setOnDragDropped(createDragDroppedHandler(pile));
		tView.setOnDragDone(createDragDoneHandler());
	}
	
	private void setFoundationsView(StackPane fView, FoundationPile pile) {
		CardPile temp = new CardPile();
        temp.copy(pile);
		for(Image img : getImageList(temp)) {
			ImageView cardView = new ImageView(img);
			
			fView.getChildren().add(cardView);
		}
		
		fView.setOnDragDetected(new EventHandler<MouseEvent>() {
    		@Override
    		public void handle(MouseEvent event) {
    			Dragboard db = fView.startDragAndDrop(TransferMode.ANY);
    			ClipboardContent cb = new ClipboardContent();
    	        move = pile;
    			cb.putString("move");
    			db.setContent(cb);
    	        event.consume();
    	        System.out.println("source detect");
    	    }
    	});
		fView.setOnDragOver(createDragOverHandler(pile));
		fView.setOnDragDropped(createDragDroppedHandler(pile));
		fView.setOnDragDone(createDragDoneHandler());
	}
	
	private void setDeckView(StackPane dcView, DeckPile pile) {
		CardPile temp = new CardPile();
        temp.copy(pile);
        
		for(Image img : getImageList(temp)) {
			ImageView cardView = new ImageView(img);
			dcView.getChildren().add(cardView);
		}
		
		dcView.setOnDragDetected(new EventHandler<MouseEvent>() {
    		@Override
    		public void handle(MouseEvent event) {
    			Dragboard db = dcView.startDragAndDrop(TransferMode.ANY);
    			ClipboardContent cb = new ClipboardContent();
    	        move = pile;
    			cb.putString("move");
    			db.setContent(cb);
    	        event.consume();
    	        System.out.println("source detect");
    	    }
    	});
		dcView.setOnDragOver(createDragOverHandler(pile));
		dcView.setOnDragDropped(createDragDroppedHandler(pile));
		dcView.setOnDragDone(createDragDoneHandler());
	}
	
	private void setDiscardView(StackPane dView, DiscardPile pile) {
		CardPile temp = new CardPile();
        temp.copy(pile);
		for(Image img : getImageList(temp)) {
			ImageView cardView = new ImageView(img);
			
			dView.getChildren().add(cardView);
		}
		
		dView.setOnDragDetected(new EventHandler<MouseEvent>() {
    		@Override
    		public void handle(MouseEvent event) {
    			Dragboard db = dView.startDragAndDrop(TransferMode.ANY);
    			ClipboardContent cb = new ClipboardContent();
    	        move = pile;
    			cb.putString("move");
    			db.setContent(cb);
    	        event.consume();
    	    }
    	});
		dView.setOnDragOver(createDragOverHandler(pile));
		dView.setOnDragDropped(createDragDroppedHandler(pile));
		dView.setOnDragDone(createDragDoneHandler());
	}
    
    private EventHandler<DragEvent> createDragOverHandler(CardPile pile) {
    	return new EventHandler<DragEvent>() {
    		@Override
    		public void handle(DragEvent event) {
    	        Dragboard db = event.getDragboard();
    	        if(db.hasString()) {
    	        	event.acceptTransferModes(TransferMode.ANY);
    	        }
    	        event.consume();
    	    }
    	};
    }
    
    private EventHandler<DragEvent> createDragDroppedHandler(CardPile pile) {
    	return new EventHandler<DragEvent>() {
    		@Override
    		public void handle(DragEvent event) {
    			//Dragboard db = event.getDragboard();
    			boolean result = game.move(move, pile);
    			if(result) {
    				game.setScore(move, pile);
    			}
    			event.setDropCompleted(result);
    	        event.consume();
    	    }
    	};
    }
    
    private EventHandler<DragEvent> createDragDoneHandler() {
    	return new EventHandler<DragEvent>() {
    		@Override
    		public void handle(DragEvent event) {
    			game.updateTableau();
    			resetView();
    	        move = null;
    	        if(game.gameWon()) {
    	        	main.setScore(game.getScore());
    	        	main.openMenuView();
    	        	main.openNamePromptStage();
    	        }
    	        event.consume();
    	    }
    	};
    }
    
    @FXML
    private void openNewGame(ActionEvent event) {
    	main.openDrawOneGame();
    }
    
    @FXML
    private void quitGame(ActionEvent event) {
    	main.openMenuView();
    }
    
    public void setScoreCounter(String newScore) {
    	scoreText.setText(newScore);
    }
}
