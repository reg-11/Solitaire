
package application;
	
import java.io.IOException;

import controller.DrawOneController;
import controller.DrawThreeController;
import controller.LeaderboardController;
import controller.MenuController;
import controller.NamePromptController;
import controller.NewGameController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;


public class Main extends Application {
	private Stage primaryStage;
	private Integer score;
	
	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
		
		try {
			openMenuView();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void openMenuView() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("/view/MenuView.fxml"));
			Pane menuFXML = (Pane) loader.load();
			
			Scene scene = new Scene(menuFXML);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Solitaire");
			primaryStage.getIcons().add(new Image("/image/icon.png"));
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			
			MenuController menuController = loader.getController();
			menuController.setMain(this);			
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void openLeaderboardView() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("/view/LeaderboardView.fxml"));
			Pane leaderboardFXML = (Pane) loader.load();
			
			Scene scene = new Scene(leaderboardFXML);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Leaderboard");
			primaryStage.getIcons().add(new Image("/image/icon.png"));
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			
			LeaderboardController leaderboardController = loader.getController();
			leaderboardController.setMain(this);
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void openNewGameView() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("/view/NewGameView.fxml"));
			Pane newGameFXML = (Pane) loader.load();
	
			Scene scene = new Scene(newGameFXML);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("New Game");
			primaryStage.getIcons().add(new Image("/image/icon.png"));
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			
			NewGameController newGameController = loader.getController();
			newGameController.setMain(this);
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void openDrawOneGame() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("/view/DrawOneView.fxml"));
			Pane drawOneFXML = (Pane) loader.load();
	
			Scene scene = new Scene(drawOneFXML);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Solitaire");
			primaryStage.getIcons().add(new Image("/image/icon.png"));
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			
			DrawOneController solitController = loader.getController();
			solitController.setMain(this);
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void openDrawThreeGame() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("/view/DrawThreeView.fxml"));
			Pane drawOneFXML = (Pane) loader.load();
	
			Scene scene = new Scene(drawOneFXML);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Solitaire");
			primaryStage.getIcons().add(new Image("/image/icon.png"));
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			
			DrawThreeController solitController = loader.getController();
			solitController.setMain(this);
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void openNamePromptStage() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("/view/NamePromptView.fxml"));
			Pane namePromptFXML = (Pane) loader.load();
			
			NamePromptController namePromptController = loader.getController();
			
			//sets score in main
			namePromptController.setScore(score);
			
			Scene scene = new Scene(namePromptFXML);
			Stage namePromptStage = new Stage();
			namePromptStage.setTitle("Congratulations!");
			namePromptStage.getIcons().add(new Image("/image/icon.png"));
			namePromptStage.initModality(Modality.WINDOW_MODAL);
			namePromptStage.setResizable(false);
			namePromptStage.initOwner(primaryStage);
			namePromptStage.setScene(scene);
			namePromptStage.show();
			
			
			
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void setScore(Integer score) {
		this.score = score;
	}
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
